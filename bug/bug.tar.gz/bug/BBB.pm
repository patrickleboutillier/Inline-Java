package BBB;

BEGIN {
   print STDERR "loading BBB\n";
}

use BCEL (
    STUDY => [qw{
        org.apache.bcel.generic.InstructionConstants
        org.apache.bcel.generic.ClassGen
        org.apache.bcel.generic.FieldGen
        org.apache.bcel.generic.InstructionList
        org.apache.bcel.generic.MethodGen
        org.apache.bcel.generic.Type
        org.apache.bcel.generic.ObjectType
        org.apache.bcel.generic.ArrayType
    }],
    DEBUG => 0,
);

1;
