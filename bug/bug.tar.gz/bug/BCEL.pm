package BCEL;

sub import {
    my $pkg = shift;
    require Inline;
    import Inline (
        Java => 'STUDY',
        JNI => 0,
        DEBUG => 0,
        CLASSPATH => "./bcel.jar",
        AUTOSTUDY => 1,
        @_,
    );
}

1;
