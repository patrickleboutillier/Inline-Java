package AAA;

BEGIN {
   print STDERR "loading AAA\n";
}

use BCEL (
    STUDY => [qw{
        org.apache.bcel.classfile.ClassParser
        org.apache.bcel.generic.InstructionList
        org.apache.bcel.generic.ConstantPoolGen
        org.apache.bcel.generic.Type
    }],
);

1;
