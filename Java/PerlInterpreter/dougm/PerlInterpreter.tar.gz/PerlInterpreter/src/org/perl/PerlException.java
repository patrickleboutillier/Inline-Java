package org.perl;

public class PerlException extends Exception {

    public PerlException() {
        super();
    }

    public PerlException(String msg) {
        super(msg);
    }
}
